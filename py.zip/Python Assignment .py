#!/usr/bin/env python
# coding: utf-8

# # 1.Check whether given array is Monotonic or not.

# In[1]:


def monotonous(a,n):#creating a function,which take 2 parameter. first one is array and 2nd parameter is lenth of array
    
    if(all(a[i]<= a[i+1] for i in range(n-1))): #checking and printing TRUE if a[i]<=a[i+1] in for loop start from zero to n-1
        print("Output: True")
    elif (all(a[i]>=a[i+1]for i in range(n-1))):#checking and printing TRUE if a[i]>=a[i+1] in for loop start from zero to n-1
        print("Output: True") 
    else:  #else print Flase
        print("Output: False")
        
a=[10,8,2,2]   #creating array

monotonous(a,len(a)) #calling the function


# # 2.Given a string check if it is palindrome or not.

# In[2]:


def palindrome(a):  #creating a function palindrome which take parameter array as input
    return a == a[::-1]   #this line will return TRUE-if string is plaindrome OR FALSE- if string is not palindrome 
a=input("Input: ") #taking input from user
print("Output:",palindrome(a)) #this line will print the output by calling the funciton 


# # 3.Given a list of integers with duplicate elements in it. Print a new list which contains the elements which appear more than one time.

# In[3]:


def Duplicate(list): #creating function Duplicate which take list as a parameter
    duplicate_list =[] #creating new list which will contian duplicate elements 

    for i in range(len(list)): #creating a for loop which start with 0 and goes till length of the list
        for j in range(i+1,len(list)): #creating 2nd for loop to deceted dulpicate element which start from i+1 and goes still length of list
            if list[i] == list[j] and list[i] not in duplicate_list: #if we find duplicate elements and that is not present in duplicate_list then
                duplicate_list.append(list[i]) #we will append that to the duplicate_list
    print("Output is: ",duplicate_list) #printing duplicate_list 
    
list=[-5 , -6, 7, 10, -5, 10, -6, 7] #input list

Duplicate(list)#calling funciton Duplicate


# In[ ]:




